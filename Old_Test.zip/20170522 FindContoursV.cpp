#include <cmath>
#include <iostream>
#include <opencv.hpp>

using namespace cv;
using namespace std;

int RemoveSmallArea(const Mat& src, Mat& dst, int flt, long area);

void main()
{
	Mat src, dst;	int area = 5, flt = 128;
	namedWindow("Source");	namedWindow("Result");
	createTrackbar("Area", "Result", &area, 20);
	createTrackbar("Thresh", "Result", &flt, 150);

	VideoCapture cap("D:/Hua/uvs170418-003.avi");
	while ((waitKey(50) & 255) != 13)
	{
		cap >> dst;	cap >> src;
		if (dst.empty())	break;
		RemoveSmallArea(src, dst, flt, pow(2, area));
		imshow("Source", src);	imshow("Result", dst);
	}//end while
}//end main

int RemoveSmallArea(const Mat& src, Mat& dst, int flt, long area)
{
	vector<Vec4i> hierarchy;
	vector<vector<Point> > contours;
	cvtColor(src, dst, CV_BGR2GRAY);	dst = dst > flt;
	findContours(dst, contours, hierarchy, CV_RETR_CCOMP, CV_CHAIN_APPROX_NONE);
	//findContours(dst, contours, hierarchy, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);

	int num = 0;	dst = src > 256;	Scalar color(255, 255, 255);
	for (int id = 0; id >= 0; id = hierarchy[id][0])
	{
		if (contourArea(contours[id]) > area)
			drawContours(dst, contours, id, color, CV_FILLED, 8, hierarchy);
		else	num++;
	}//end for
	return num;
}//end RemoveSmallArea


