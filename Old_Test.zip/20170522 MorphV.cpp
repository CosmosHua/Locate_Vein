#include<iostream>
#include<opencv.hpp>

using namespace cv;
using namespace std;

const int mid = 10;
Mat Morph(Mat& src, int iter, int sz);

void main()
{
	Mat src, dst;
	int iter = mid, size = 3, flt = 128;
	namedWindow("Source");	namedWindow("Result");
	createTrackbar("Thresh", "Source", &flt, 255);
	createTrackbar("Size", "Result", &size, 10);
	createTrackbar("Iter", "Result", &iter, 2 * mid);

	VideoCapture cap("D:/Hua/uvs170418-003.avi");
	while ((waitKey(50) & 255) != 13)
	{
		cap >> dst;	cap >> src;
		if (dst.empty())	break;
		imshow("Source", src);
		imshow("Result", Morph(dst, iter, size) > flt);
	}//end while
}//end main

Mat Morph(Mat& src, int iter, int sz)
{
	iter -= mid;	Mat dst;
	if (sz < 1 || iter < 1)	return src;
	Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(sz, sz));
	if(iter > 0)
		erode(src, dst, kernel, Point(-1,-1), iter);
	else
		dilate(src, dst, kernel, Point(-1, -1), -iter);
	return dst;
}//end Morph