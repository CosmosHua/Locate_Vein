#include <cmath>
#include <iostream>
#include <opencv.hpp>

using namespace cv;
using namespace std;

Point2d FindRect(const Mat& src, int flt);

void main()
{
	Mat src = imread("F:/Test/111.png");
	namedWindow("Source");	int flt = 128;
	createTrackbar("Thresh", "Source", &flt, 150);

	cout << FindRect(src, flt);
	cout << " From " << Point2d(src.cols, src.rows) << endl;
	imshow("Source", src);	waitKey();
}//end main

Point2d FindRect(const Mat& src, int flt)
{
	Mat dst;	cvtColor(src, dst, CV_BGR2GRAY);	dst = dst < flt;
	vector<vector<Point> > contours;	vector<Vec4i> hierarchy;
	findContours(dst, contours, hierarchy, CV_RETR_CCOMP, CHAIN_APPROX_NONE);

	Point2d now, pre(contourArea(contours[0]), arcLength(contours[0], true));
	for (int id = 0; id >= 0; id = hierarchy[id][0])
	{
		now = Point2d(contourArea(contours[id]), arcLength(contours[id], true));
		if (now.x > pre.x)	pre = now;
	}//end for
	double delta = sqrt(pre.y * pre.y - 16 * pre.x);
	now.x = (pre.y - delta) / 4;
	now.y = (pre.y + delta) / 4;
	return now;
}//end RemoveSmallArea


