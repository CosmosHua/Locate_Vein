#include <iostream>
#include <opencv.hpp>
using namespace cv;
using namespace std;

Mat Clear(Mat& im, int dense, int templa, int search, int thred);

void main(int argc, char** argv)
{
	char* filename = "F:/Test/Gray.png"; //default
	if (argc > 1)	filename = argv[1];
	Mat src = imread(filename, 0);
	namedWindow("Source");	namedWindow("Result");

	int dense = 25, templa = 1, search = 20, thred = 130;//initial value
	createTrackbar("Strength", "Source", &dense, 30);
	createTrackbar("Template", "Source", &templa, 10);
	createTrackbar("Search", "Source", &search, 122);
	createTrackbar("Threshold", "Result", &thred, 255);

	imshow("Source", src);
	while ((waitKey(100) & 255) != 13)//press Enter to exit
		imshow("Result", Clear(src, dense, templa, search, thred));
}//end main

Mat Clear(Mat& im, int dense, int templa, int search, int thred)
{
	templa = 2*templa + 1;	search = 2*search + 1;	Mat dst;
	fastNlMeansDenoising(im, dst, dense, templa, search); //Denoising
	//if(dense > 0)	equalizeHist(dst, dst); //Histogram Equalization
	//Canny(im, dst, thred, search);
	return dst;
}//end Clear
