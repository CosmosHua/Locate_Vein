#include <iostream>
#include <opencv.hpp>
#include <features2d.hpp>
#include <nonfree\features2d.hpp>

using namespace cv;
using namespace std;

void main(int argc, char** argv)
{
	//Mat image = imread(argv[1]);
	Mat image = imread("F:/Test/Gray.png");
	//image = image > 128;

	SimpleBlobDetector::Params params;
	params.minThreshold = 40;
	params.maxThreshold = 160;
	params.thresholdStep = 5;
	params.minArea = 1;
	params.minConvexity = .05f;
	params.minInertiaRatio = .05f;
	params.maxArea = 500;
	SimpleBlobDetector blobDetect(params);

	vector<KeyPoint> keyPoints;
	blobDetect.detect(image, keyPoints);

	cout << keyPoints.size() << endl;
	drawKeypoints(image, keyPoints, image, Scalar(255, 0, 0));

	namedWindow("blobs");	imshow("blobs", image);
	waitKey();
}//end main