#include<iostream>
#include<opencv.hpp>

using namespace std;
using namespace cv;

const int mid = 10;
Mat Morph(Mat& src, int iter, int sz);
Mat MorphEx(Mat& src, int iter, int sz, int type);

void main()
{
	int iter = mid, size = 3, type = 7;
	Mat src = imread("F:/Test/Gray.png");
	normalize(src, src, 0, 255, NORM_MINMAX);

	namedWindow("Source");	imshow("Source", src);
	namedWindow("Result");
	createTrackbar("Type", "Source", &type, 7);
	createTrackbar("Size", "Result", &size, 10);
	createTrackbar("Iter", "Result", &iter, 2 * mid);

	while ((waitKey(50) & 255) != 13)
		//imshow("Result", Morph(src, iter, size) > 128);
		imshow("Result", MorphEx(src, iter, size, type));
}//end main

Mat MorphEx(Mat& src, int iter, int sz, int type)
{
	if (!sz)	return src;
	if (type > 6)	return Morph(src, iter, sz);
	Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(sz, sz));
	Mat dst;	morphologyEx(src, dst, type, kernel, Point(-1,-1), iter);
	return dst;
}//end MorphEx

Mat Morph(Mat& src, int iter, int sz)
{
	iter -= mid;	Mat dst;
	if (sz < 1 || iter < 1)	return src;
	Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(sz, sz));
	if(iter > 0)
		erode(src, dst, kernel, Point(-1,-1), iter);
	else
		dilate(src, dst, kernel, Point(-1, -1), -iter);
	return dst;
}//end Morph