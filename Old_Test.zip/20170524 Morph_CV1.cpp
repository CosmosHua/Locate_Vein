#include<iostream>
#include<opencv.hpp>

using namespace std;
using namespace cv;

Mat Morph(const Mat& src, int iter = 1, int sz = 3)
{
	if (sz < 1 || iter < 1)	return src;
	Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(sz, sz)), dst;
	cvtColor(src, dst, CV_RGB2GRAY);
	normalize(dst, dst, 0, 255, NORM_MINMAX);
	erode(dst, dst, kernel, Point(-1, -1), iter);
	return dst > 128;
}//end Morph

void Morph(IplImage* src0)
{
	CvSize ss = cvSize(src0->width, src0->height);
	IplImage* tmp = cvCreateImage(ss, src0->depth, 1);
	cvCvtColor(src0, tmp, CV_RGB2GRAY);
	cvNormalize(tmp, tmp, 0, 255, NORM_MINMAX);
	cvErode(tmp, tmp);
	cvDilate(tmp, tmp);
	//cvThreshold(tmp, tmp, 128, 255, CV_THRESH_BINARY);
	cvCvtColor(tmp, src0, CV_GRAY2RGB);
	//cvAdaptiveThreshold();
}//end Morph


void main()
{
	int iter = 1, size = 3, type = 7;
	Mat src = imread("F:/Test/Gray.png"), dst = src.clone();
	//normalize(src, src, 0, 255, NORM_MINMAX);
	namedWindow("Source");	imshow("Source", src);
	namedWindow("Result");
	Morph(&(IplImage)src);	imshow("Result", src);
	waitKey();

	while ((waitKey(50) & 255) != 13)
	{
		//imshow("Result", Morph(src));
		//cvErode(&(IplImage)src, &(IplImage)dst);
	}//end while
}//end main


